RAZZ PORTFOLIO — PERSONALIZED PHASE 1

Stack: Next.js 15, TypeScript, Tailwind CSS 3, Framer Motion, Lucide icons.
Theme: black / white / silver.
Confirmed content: learning web development with AI-assisted guidance; Python, HTML, CSS; birthday wish website; Instagram; public contact email.

ANDROID PHONE WORKFLOW (recommended: GitHub Codespaces)

1. Download this ZIP to your phone.
2. On GitHub, create a repository named `razz-portfolio`.
3. Upload this ZIP to the repository and commit it.
4. Open Code > Codespaces > Create codespace on main (availability/usage limits depend on your account).
5. In terminal, extract ZIP. If it creates a nested folder, enter that folder:
   unzip razz-portfolio-phase1-personalized.zip -d .
   npm install
   npm run dev -- --hostname 0.0.0.0
6. Open the forwarded port 3000 link to view the site.

CHECKS:
   npx tsc --noEmit
   npm run build

Then inspect on phone:
- no horizontal scrolling at narrow width
- hero, project cards, contact links fit
- keyboard/focus styles remain visible
- system reduced-motion setting is respected
- no build/type errors
- email link opens mail app
- Instagram opens the intended profile

IMPORTANT:
- Profile image is currently a designed R. orb. Add your image as `public/images/profile.jpg` only after you upload/choose it and update the component to use it.
- Birthday website project is described from the known details, but no live demo or repository link is claimed.
- Portfolio is still in progress; no fake job experience, client work, metrics, or certificates are included.
- The email is intentionally public on the website because you supplied it for that purpose. If you prefer privacy, use a contact form or a separate public email.
- Never add API keys or passwords to frontend code.
