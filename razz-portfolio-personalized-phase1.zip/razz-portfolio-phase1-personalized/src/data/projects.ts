export type PortfolioProject = {
  number: string;
  name: string;
  type: string;
  description: string;
  status: "Built" | "In progress";
  tags: string[];
  href?: string;
};

export const projects: PortfolioProject[] = [
  {
    number: "01",
    name: "Birthday Wish Website",
    type: "PERSONAL WEB PROJECT",
    description: "A romantic birthday surprise website with a midnight countdown, photo gallery, love-letter section, surprise reveal, and animated details.",
    status: "Built",
    tags: ["HTML", "CSS", "JavaScript", "Responsive Design"]
  },
  {
    number: "02",
    name: "RAZZ Portfolio",
    type: "PERSONAL PORTFOLIO",
    description: "This portfolio: a dark, minimal space to document my learning journey, share real projects, and keep improving my web development skills.",
    status: "In progress",
    tags: ["Next.js", "TypeScript", "Tailwind CSS", "Motion"]
  }
];
