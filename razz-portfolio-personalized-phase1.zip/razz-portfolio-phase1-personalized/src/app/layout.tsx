import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RAZZ | Developer Portfolio",
  description: "RAZZ is learning web development and building projects with AI-assisted guidance.",
  openGraph: { title: "RAZZ | Developer Portfolio", description: "Learning, building, and improving one project at a time.", type: "website" }
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#08090b" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
