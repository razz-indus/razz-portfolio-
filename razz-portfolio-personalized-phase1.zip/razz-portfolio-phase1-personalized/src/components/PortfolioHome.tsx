"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, Code2, Github, Instagram, Mail, MoveUpRight, Sparkles } from "lucide-react";
import { projects } from "@/data/projects";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const reduceMotion = useReducedMotion();
  return <motion.div
    initial={reduceMotion ? false : { opacity: 0, y: 22 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.18 }}
    transition={{ duration: reduceMotion ? 0 : 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
  >{children}</motion.div>;
}

const skills = ["Python", "HTML", "CSS", "Learning Next.js", "Learning TypeScript"];

export default function PortfolioHome() {
  return <main className="min-h-screen overflow-hidden bg-ink text-white">
    <div className="site-grid pointer-events-none absolute inset-x-0 top-0 h-[720px]" />
    <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-5 py-6 sm:px-8 lg:px-12">
      <a href="#top" className="text-sm font-black tracking-[0.28em]" aria-label="RAZZ home">RAZZ<span className="text-silver">.</span></a>
      <nav className="hidden items-center gap-8 text-xs text-muted sm:flex" aria-label="Main navigation">
        <a className="transition hover:text-white" href="#work">WORK</a><a className="transition hover:text-white" href="#about">ABOUT</a><a className="transition hover:text-white" href="#contact">CONTACT</a>
      </nav>
      <a href="#contact" className="rounded-full border border-white/20 px-4 py-2 text-xs transition hover:border-white hover:bg-white hover:text-black">LET&apos;S TALK <ArrowUpRight className="ml-1 inline h-3 w-3" /></a>
    </header>

    <section id="top" className="relative mx-auto grid min-h-[78vh] max-w-7xl items-center gap-12 px-5 pb-24 pt-16 sm:px-8 md:grid-cols-[1.25fr_.75fr] lg:min-h-[82vh] lg:px-12">
      <Reveal>
        <div className="mb-8 flex items-center gap-3 text-[10px] tracking-[0.24em] text-muted sm:text-xs"><span className="h-px w-8 bg-silver" /> DEVELOPER IN PROGRESS</div>
        <h1 className="max-w-4xl text-[clamp(3.7rem,12vw,8.5rem)] font-semibold leading-[0.86] tracking-[-0.085em]">LEARN.<br /><span className="text-silver">BUILD.</span><br />REPEAT<span className="text-silver">.</span></h1>
        <p className="mt-8 max-w-xl text-base leading-7 text-muted sm:text-lg">I&apos;m RAZZ, a developer learning web development with AI-assisted guidance and hands-on projects. I&apos;m building my skills one experiment at a time.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#work" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-medium text-black transition hover:bg-silver">Explore my work <ArrowDownRight size={16} /></a>
          <a href="https://www.instagram.com/razz_xo5/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-sm transition hover:border-white"><Instagram size={16} /> Instagram</a>
        </div>
      </Reveal>
      <Reveal delay={0.12}>
        <div className="relative mx-auto flex aspect-square w-full max-w-[330px] items-center justify-center sm:max-w-[390px]">
          <div className="absolute inset-0 rounded-full border border-white/10" />
          <div className="absolute inset-[9%] rounded-full border border-white/10" />
          <div className="profile-orb relative flex h-[68%] w-[68%] items-center justify-center rounded-full">
            <span className="text-5xl font-semibold tracking-[-0.09em] text-white sm:text-6xl">R<span className="text-[#c5c8ce]">.</span></span>
          </div>
          <div className="absolute bottom-[8%] right-0 rounded-full border border-white/15 bg-[#111317]/90 px-4 py-2 text-[10px] tracking-[0.15em] text-silver backdrop-blur">CURIOUS BY DEFAULT</div>
          <Sparkles className="absolute right-[13%] top-[10%] text-silver" size={19} />
        </div>
      </Reveal>
      <div className="absolute bottom-7 left-5 right-5 flex items-center justify-between border-t border-white/10 pt-4 text-[9px] tracking-[0.18em] text-muted sm:left-8 sm:right-8 lg:left-12 lg:right-12"><span>SELF-TAUGHT JOURNEY</span><span>DESIGN · CODE · CURIOSITY</span><span>SCROLL ↓</span></div>
    </section>

    <section id="work" className="relative mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
      <Reveal><div className="mb-10 flex items-end justify-between gap-4 border-b border-white/15 pb-5"><div><p className="mb-3 text-[10px] tracking-[0.24em] text-muted">SELECTED WORK</p><h2 className="text-4xl font-medium tracking-[-0.06em] sm:text-6xl">Projects<span className="text-silver">.</span></h2></div><span className="pb-1 text-xs text-muted">02 PROJECTS</span></div></Reveal>
      <div className="grid gap-4 md:grid-cols-2">
        {projects.map((project, index) => <Reveal key={project.number} delay={index * 0.08}>
          <article className="group flex h-full min-h-[330px] flex-col justify-between rounded-2xl border border-white/10 bg-panel p-6 transition duration-300 hover:-translate-y-1 hover:border-white/30 sm:p-8">
            <div className="flex items-start justify-between gap-3"><span className="text-xs text-muted">{project.number} / {project.type}</span><span className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-silver transition group-hover:bg-white group-hover:text-black"><MoveUpRight size={16} /></span></div>
            <div className="mt-12"><div className="mb-3 text-[10px] tracking-[0.15em] text-silver">{project.status.toUpperCase()}</div><h3 className="text-2xl font-medium tracking-tight sm:text-3xl">{project.name}</h3><p className="mt-3 text-sm leading-6 text-muted">{project.description}</p><div className="mt-5 flex flex-wrap gap-2">{project.tags.map(tag => <span key={tag} className="rounded-full border border-white/10 px-3 py-1 text-[10px] tracking-wide text-silver">{tag}</span>)}</div></div>
          </article>
        </Reveal>)}
      </div>
      <p className="mt-5 text-xs text-muted">I&apos;ll add live demos and source links when they&apos;re ready to share.</p>
    </section>

    <section id="about" className="mx-auto grid max-w-7xl gap-10 border-t border-white/10 px-5 py-20 sm:px-8 md:grid-cols-[0.8fr_1.2fr] lg:px-12 lg:py-28">
      <Reveal><p className="text-[10px] tracking-[0.24em] text-muted">ABOUT / CURRENT FOCUS</p><h2 className="mt-4 text-4xl font-medium tracking-[-0.06em] sm:text-6xl">Learning in public<span className="text-silver">.</span></h2></Reveal>
      <Reveal delay={0.1}><div className="border-l border-white/20 pl-6 sm:pl-8"><Code2 className="mb-6 text-silver" size={25} /><p className="text-lg leading-8 text-silver sm:text-xl">I&apos;m currently learning web development with AI as a guide, then putting that learning into practice by building small projects and improving them step by step.</p><p className="mt-5 text-sm leading-7 text-muted">I value curiosity, experimentation, and understanding how things work—not just making them look good.</p><div className="mt-7 flex flex-wrap gap-2">{skills.map(skill => <span key={skill} className="rounded-full border border-white/10 px-3 py-2 text-xs text-silver">{skill}</span>)}</div></div></Reveal>
    </section>

    <section id="contact" className="mx-auto max-w-7xl px-5 pb-16 pt-10 sm:px-8 lg:px-12">
      <Reveal><div className="rounded-3xl border border-white/10 bg-[#101114] p-7 sm:p-12 lg:p-16"><p className="text-[10px] tracking-[0.24em] text-muted">HAVE SOMETHING IN MIND?</p><h2 className="mt-5 max-w-3xl text-4xl font-medium leading-tight tracking-[-0.06em] sm:text-6xl">Let&apos;s build something <span className="text-silver">useful.</span></h2><p className="mt-5 max-w-lg text-sm leading-7 text-muted">For project ideas, collaboration, or a friendly hello, you can reach me here.</p><a href="mailto:rajsolankee015@gmail.com" className="mt-8 inline-flex items-center gap-3 rounded-full bg-white px-5 py-3 text-sm font-medium text-black transition hover:bg-silver"><Mail size={16} /> Email RAZZ</a><div className="mt-5 flex flex-wrap gap-4 text-sm text-silver"><a className="inline-flex items-center gap-2 hover:text-white" href="https://www.instagram.com/razz_xo5/" target="_blank" rel="noreferrer"><Instagram size={16} /> Instagram <ArrowUpRight size={13} /></a><span className="inline-flex items-center gap-2 text-muted"><Github size={16} /> GitHub link coming soon</span></div></div></Reveal>
      <footer className="flex flex-col gap-3 py-8 text-[10px] tracking-[0.15em] text-muted sm:flex-row sm:items-center sm:justify-between"><span>© {new Date().getFullYear()} RAZZ — DEVELOPER PORTFOLIO</span><span>LEARN. BUILD. REPEAT.</span></footer>
    </section>
  </main>;
}
